//
//  DetailViewController.h
//  RecipeAppDo1
//
//  Created by Warren Goh on 4/30/15.
//  Copyright (c) 2015 WG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic, assign) NSInteger recipeIndex;

@end
