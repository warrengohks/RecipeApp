//
//  RecipesTableDataSource.h
//  RecipeAppDo1
//
//  Created by Warren Goh on 4/29/15.
//  Copyright (c) 2015 WG. All rights reserved.
//

#import <Foundation/Foundation.h>
@import UIKit;

@interface RecipesTableDataSource : NSObject <UITableViewDataSource>

-(void) registerTableView: (UITableView *)tableView;


@end
